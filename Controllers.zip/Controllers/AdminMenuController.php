<?php

namespace App\Http\Controllers;

use App\Models\menu;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class AdminMenuController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $katakunci = $request->katakunci;
        $paginate = 1;
        if(strlen($katakunci)){
            $menus = menu::where('id', 'like', "%$katakunci%")
            ->orWhere('nama_makanan', 'like', "%$katakunci%")
            ->orWhere('deskripsi', 'like', "%$katakunci%")
            ->orWhere('harga', 'like', "%$katakunci%")
            ->paginate($paginate);
        } else {
            $menus = menu::orderBy('id', 'desc')->paginate($paginate);
        }

        return view('admin.menu.index', compact('menus'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.menu.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'nama_makanan' => 'required',
            'deskripsi' => 'required',
            'harga' => 'required',
            'gambar' => 'required',
        ]);

        $imageName = $request->file('gambar')->hashName();
        $validated['gambar'] = $imageName;
        $directory = public_path() . '/asset-gambar';
        $request->file('gambar')->move($directory, $imageName);
        
        menu::create($validated);
        return redirect()->route('admin.menu.index')->with('success', 'Data berhasil ditambahkan!');
    }

    /**
     * Display the specified resource.
     */
    public function show(menu $menu)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(menu $menu, String $id)
    {
        $menus = menu::find($id);
        return view('admin.menu.edit', compact('menus'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, String $id)
    {
        $validated = $request->validate([
            'nama_makanan' => 'required',
            'deskripsi' => 'required',
            'harga' => 'required',
            'gambar' => 'required',
        ]);

        $menus = menu::find($id);

        File::delete(public_path() . "/asset-gambar/$menus->gambar");

        $imageName = $request->file('gambar')->hashName();
        $validated['gambar'] = $imageName;
        $directory = public_path() . '/asset-gambar';
        $request->file('gambar')->move($directory, $imageName);
        $menus->update($validated);

        return redirect()->route('admin.menu.index')->with('success', 'Data berhasil diedit!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(String $id)
    {
        $menus = menu::find($id);
        File::delete(public_path() . "/asset-gambar/$menus->gambar");
        $menus->delete();

        return redirect()->route('admin.menu.index')->with('success', 'Data berhasil dihapus!');
    }
}