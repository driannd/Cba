<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('login.login');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);

        if(Auth::attempt($validated)){
            $users = Auth::user();

            if($users->role === 'admin'){
                return redirect()->route('admin.dashboard');
            } else {
                return redirect('/');
            }
        }
        return back()->with('error', 'Login Gagal!');
    }

    public function logout(){
        Auth::logout();
        return redirect('/');
    }
}